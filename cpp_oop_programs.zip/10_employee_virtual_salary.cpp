#include <iostream>
using namespace std;

class Employee {
public:
    virtual void salary() {
        cout << "Employee salary" << endl;
    }
};

class Manager : public Employee {
public:
    void salary() {
        cout << "Manager salary: 50000" << endl;
    }
};

class Developer : public Employee {
public:
    void salary() {
        cout << "Developer salary: 40000" << endl;
    }
};

int main() {
    Employee* e;
    Manager m;
    Developer d;

    e = &m;
    e->salary();

    e = &d;
    e->salary();
}
