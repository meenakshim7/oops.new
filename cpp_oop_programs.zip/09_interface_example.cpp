#include <iostream>
using namespace std;

class Drawable {
public:
    virtual void draw() = 0;
};

class Rectangle : public Drawable {
public:
    void draw() {
        cout << "Drawing Rectangle" << endl;
    }
};

int main() {
    Rectangle r;
    r.draw();
}
